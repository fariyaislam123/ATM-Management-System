/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atmmanagementsystem;

/**
 *
 * @author User
 */
public class AtmManagementSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        splashscreen ob = new splashscreen();
        ob.setVisible(true);
        try{
            for(int i=0;i<100;i++){
                Thread.sleep(60);
                ob.lbl.setText(Integer.toString(i)+"%");
                ob.bar.setValue(i);
                CustomerLogin lg = new CustomerLogin();
                if(i==99){
                    lg.setVisible(true);
                    ob.setVisible(false);
                }
            }
        
           }catch(Exception e){
            
        }
        
          
                
            
        
        
    
    }
    

